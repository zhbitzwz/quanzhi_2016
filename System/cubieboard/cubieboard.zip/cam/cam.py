# _*_ coding:utf-8 _*_
import cv2
import numpy as np
from websocket import *
import base64

cap=cv2.VideoCapture(0)#打开1号摄像头
success, frame = cap.read()#读取一桢图像，前一个返回值是是否成功，后一个返回值是图像本身
color = (0,255,0)#设置人脸框的颜色
color2 = (0,255,255)#设置人脸框的颜色
classfier=cv2.CascadeClassifier("/home/zzm/python/haarcascade_eye_tree_eyeglasses.xml")#定义分类器
classfier2=cv2.CascadeClassifier("/home/zzm/python/haarcascade_frontalface_alt2.xml")#定义分类器
HOST = ""
PORT = 33456
LISTEN = 5

while True:
    print "server start!"
    sock = websocket(HOST, PORT, LISTEN)
    con, add = sock.sock.accept()
    print "connection from ", add
    sock.wshandshake(con)
    while success:
        success, frame = cap.read()
        frame = cv2.resize(frame, (320,240), interpolation=cv2.INTER_CUBIC)
        #size=frame.shape[:2]
        #image=np.zeros(size,dtype=np.float16)
        #image = cv2.cvtColor(frame, cv2.cv.CV_BGR2GRAY)
        #cv2.equalizeHist(image, image)

        #divisor=20
        #h, w = size
        #minSize=(w/divisor, h/divisor)
        #faceRects = classfier.detectMultiScale(image, 1.2, 2, cv2.CASCADE_SCALE_IMAGE,minSize)#人脸检测
        #faceRects2 = classfier2.detectMultiScale(image, 1.2, 2, cv2.CASCADE_SCALE_IMAGE,minSize)#人脸检测
        #if len(faceRects)>0:#如果人脸数组长度大于0
        #    for faceRect in faceRects: #对每一个人脸画矩形框
         #       x, y, w, h = faceRect
         #       cv2.rectangle(frame, (x, y), (x+w, y+h), color, thickness=3)
        #if len(faceRects2)>0:#如果人脸数组长度大于0
         #   for faceRect2 in faceRects2: #对每一个人脸画矩形框
          #      x, y, w, h = faceRect2
          #      cv2.rectangle(frame, (x, y), (x+w, y+h), color2, thickness=3)
        #cv2.imshow("test", frame)
        cv2.imwrite("/root/work/a.jpg", frame)
        f=open(r'/root/work/a.jpg','rb')
        ls_f=base64.b64encode(f.read())
        f.close()
        try:
            sock.wsSend(con, ls_f)
        except:
            sock.wsclose()
            print "server stop!"
            break
        key=cv2.waitKey(10)
        # c = chr(key & 255)
        # if c in ['q', 'Q', chr(27)]:
        #     break
    # cv2.destroyWindow("test")
