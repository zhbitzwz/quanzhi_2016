# _*_ coding:utf-8 _*_
import socket
import base64
import hashlib
import struct
import sys

class websocket:

    MAGIC_STRING = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
    HANDSHAKE_STRING = "HTTP/1.1 101 Switching Protocols\r\n" \
                        "Upgrade:websocket\r\n" \
                        "Connection: Upgrade\r\n" \
                        "Sec-WebSocket-Accept: {1}\r\n" \
                        "WebSocket-Location: ws://{2}/chat\r\n" \
                        "WebSocket-Protocol:chat\r\n\r\n"

    def __init__(self, HOST, PORT, LISTEN):
        self.HOST = HOST
        self.PORT = PORT
        self.LISTEN = LISTEN
        self.HANDSHAKE_STRING = websocket.HANDSHAKE_STRING
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            self.sock.bind((HOST, PORT))
            self.sock.listen(LISTEN)
        except:
            print ("ip or port error")
            sys.exit()

    def wshandshake(self, con):
        headers = {}
        shake = con.recv(1024)
        if not len(shake):
            return False
        header, data = shake.split('\r\n\r\n', 1)
        for line in header.split('\r\n')[1:]:
            key, val = line.split(': ', 1)
            headers[key] = val
        if 'Sec-WebSocket-Key' not in headers:
            return False
        sec_key = headers['Sec-WebSocket-Key']
        res_key = base64.b64encode(hashlib.sha1(sec_key + self.MAGIC_STRING).digest())
        str_handshake = self.HANDSHAKE_STRING.replace('{1}', res_key).replace('{2}', self.HOST + ':' + str(self.PORT))
        print 'str_handshake:' + str_handshake
        con.send(str_handshake)
        return True

    def wsSend(self, con, data):
        if data:
            data = str(data)
        else:
            return False
        token = "\x81"
        length = len(data)
        if length < 126:
            token += struct.pack("B", length)
        elif length <= 0xFFFF:
            token += struct.pack("!BH", 126, length)
        else:
            token += struct.pack("!BQ", 127, length)
        #struct为Python中处理二进制数的模块，二进制流为C，或网络流的形式。
        data = '%s%s' % (token, data)
        con.send(data)
        return True

    def wsRecv(self, con, num):
        try:
            all_data = con.recv(num)
            if not len(all_data):
                return False
        except:
            return False
        else:
            code_len = ord(all_data[1]) & 127
            if code_len == 126:
                masks = all_data[4:8]
                data = all_data[8:]
            elif code_len == 127:
                masks = all_data[10:14]
                data = all_data[14:]
            else:
                masks = all_data[2:6]
                data = all_data[6:]
                raw_str = ""
                i = 0
                for d in data:
                    raw_str += chr(ord(d) ^ ord(masks[i % 4]))
                    i += 1
            return raw_str

    def wsclose(self):
        self.sock.close()






		
