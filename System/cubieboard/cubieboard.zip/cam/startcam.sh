python ./cam.py
