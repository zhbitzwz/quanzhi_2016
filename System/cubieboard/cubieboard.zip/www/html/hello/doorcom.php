<?php
	$username = $_POST['username'];
	$resultcode = $_POST['resultcode'];
	if($resultcode == '1'){
		exec("python /root/work/moto.py open");
//		echo "ok";
	}
	if($resultcode == '2')
	{
		exec("python /root/work/moto.py close");
	}
