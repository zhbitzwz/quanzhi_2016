﻿<?php
$data = $_POST['status'];
//端口111  
$service_port = 6666;  
//本地  
$address = 'localhost';  
//创建 TCP/IP socket  
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);  
if ($socket < 0) {  
        echo "socket创建失败原因: " . socket_strerror($socket) . "\n";  
} else {  
        echo "OK，HE HE.\n";  
}  
$result = socket_connect($socket, $address, $service_port);  
if ($result < 0) {  
        echo "SOCKET连接失败原因: ($result) " . socket_strerror($result) . "\n";  
} else {  
        echo "OK.\n";  
}  
//发送命令  

$out = '';  
echo "Send Command..........";  
$in = $data;  
socket_write($socket, $in, strlen($in));  
echo "OK.\n";  
echo "Reading Backinformatin:\n\n";  

echo "Close socket........";  
socket_close($socket);  
echo "OK,He He.\n\n"; 
