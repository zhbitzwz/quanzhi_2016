<?php
	$username = $_POST['username'];
	$resultcode = $_POST['resultcode'];
	if($resultcode == '1'){
		//开灯
		exec("python /root/work/led.py on");

	}else{
		//不开灯
		exec("python /root/work/led.py off");
	}
