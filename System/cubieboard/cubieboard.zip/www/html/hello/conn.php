<?php
/**
 * Created by ZWZ.
 * Function: 链接数据库
 * Date: 2016/1/29 0:31
 */
   $db_user = "root";
   $db_pass = "484848";
   $db_host = "localhost";
   $db_port = 3307;
   $db_name = "app_zwzquanzhi";

   $connect = mysqli_connect($db_host, $db_user, $db_pass, $db_name, $db_port);
?>
