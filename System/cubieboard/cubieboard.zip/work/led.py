import sys
f=open("/sys/class/gpio/gpio9_ph20/value","wb")
f1=open("/sys/class/gpio/gpio10_pg2/value","wb")

if sys.argv[1] == 'on':
	f.write("1")
	f1.write("1")
	
if sys.argv[1] == 'off':
	f.write("0")
	f1.write("0")
	
f.close()

