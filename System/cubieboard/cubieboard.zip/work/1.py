import ctypes
import os
import sys
str=sys.argv[1]
print str
libtest = ctypes.cdll.LoadLibrary('/root/work/tts_sample.so')
libtest.say(str)
os.system("mplayer -srate 48000 /root/work/tts_sample.wav")
