import sys
import time
t1=[0x08,0x0c,0x04,0x06,0x02,0x03,0x01,0x09]
t2=[0x09,0x01,0x03,0x02,0x06,0x04,0x0c,0x08]
if sys.argv[1] == 'open':
    t=t1
if sys.argv[1] == 'close':
    t=t2
N=128
while N:
    N=N-1
    for a in t:
        sta=[]
        for i in range(0, 8):
            if(a&0x80 != 0):
                sta.append(1)
            else:
                sta.append(0)
            a=a<<1
            
        #for i in range(0, 8):
        #    print sta[i],
     
        time.sleep(0.002)
        for i in range(0, 8):
            if sta[i]==1:
                fp = open("/sys/class/gpio/gpio"+str(i+1)+"_pe"+str(i+4)+"/value", "wb")
                fp.write('1')
                fp.close()
            else:
                fp = open("/sys/class/gpio/gpio"+str(i+1)+"_pe"+str(i+4)+"/value", "wb")
                fp.write('0')
                fp.close()
                
  
