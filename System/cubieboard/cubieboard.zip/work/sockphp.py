#coding:utf-8
import socket
import os
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind(('localhost', 6666))
sock.listen(5)
while True:
    connection, address = sock.accept()
    try:
        buf = connection.recv(1024)
        if buf == "KA+":
            print "KA+"
	    os.system("python /root/work/1.py 你此刻的心情:接纳；包容；吸收；柔顺，你充满正面能量")
        if buf == "KP+":
            print "KP+"
	    os.system("python /root/work/1.py 你此刻的心情:专注；平静；出神；孤单，你充满正面能量")
	if buf == "KR+":
            print "KR+"
	    os.system("python /root/work/1.py 你此刻的心情:痛快；爽快；释放；放松，你充满正面能量")
	if buf == "CT+":
            print "CT+"
	    os.system("python /root/work/1.py 你此刻的心情:豪放；从容；开朗；豁达，你充满正面能量")
	if buf == "CG+":
            print "CG+"
	    os.system("python /root/work/1.py 你此刻的心情:决断；果敢；坚定；爽快，你充满正面能量")
	if buf == "YC+":
            print "YC+"
	    os.system("python /root/work/1.py 你此刻的心情:平和；美好；理智；祥和，你充满正面能量")
	if buf == "YL+":
            print "YL+"
	    os.system("python /root/work/1.py 你此刻的心情:舒适；轻松；自然；顺心，你充满正面能量")
	if buf == "YV+":
            print "YV+"
	    os.system("python /root/work/1.py 你此刻的心情:欢快；欢畅；舒畅；舒心，你充满正面能量")
	if buf == "ML+":
            print "ML+"
	    os.system("python /root/work/1.py 你此刻的心情:怜爱；同情；关心；甜蜜，你充满正面能量")
	if buf == "MS+":
            print "MS+"
	    os.system("python /root/work/1.py 你此刻的心情:喜欢；开心；高兴；心动，你充满正面能量")
	if buf == "WS+":
            print "WS+"
	    os.system("python /root/work/1.py 你此刻的心情:激情，积极；阳光；高涨，你充满正面能量")
	if buf == "WC+":
            print "WC+"
	    os.system("python /root/work/1.py 你此刻的心情:激动，无畏；泰然；面对，你充满正面能量")
	    
	if buf == "KA-":
            print "KA-"
	    os.system("python /root/work/1.py 你此刻的心情:急躁；着急；憋躁；憋闷，有躁狂症倾向")
	if buf == "KP-":
            print "KP-"
	    os.system("python /root/work/1.py 你此刻的心情:心乱；分心；空想；思念，有强迫症倾向")
	if buf == "KR-":
            print "KR-"
	    os.system("python /root/work/1.py 你此刻的心情:暴躁；烦躁；憋火；悸动，有焦虑症倾向")
	if buf == "CT-":
            print "CT-"
	    os.system("python /root/work/1.py 你此刻的心情:伤感；哭泣；痛心；低落，有抑郁症倾向")
	if buf == "CG-":
            print "CG-"
	    os.system("python /root/work/1.py 你此刻的心情:怯懦；犹豫；纠结；郁闷，有抑郁症倾向")
	if buf == "YC-":
            print "YC-"
	    os.system("python /root/work/1.py 你此刻的心情:生气；指责；攻击；冲动，有敌对症倾向")
	if buf == "YL-":
            print "YL-"
	    os.system("python /root/work/1.py 你此刻的心情:紧张；失调；失控；宣泄，有人际关系敏感症倾向")
	if buf == "YV-":
            print "YV-"
	    os.system("python /root/work/1.py 你此刻的心情:压抑；窝心；别扭；想念，有抑郁症倾向")
	if buf == "ML-":
            print "ML-"
	    os.system("python /root/work/1.py 你此刻的心情:哀伤；失落；幽怨；寂寞，有偏执症倾向")
	if buf == "MS-":
            print "MS-"
	    os.system("python /root/work/1.py 你此刻的心情:记恨；怨恨；仇恨；哀厌，有偏执症倾向")
	if buf == "WC-":
            print "WC-"
	    os.system("python /root/work/1.py 你此刻的心情:恐惧；害怕；惊恐；焦虑，有恐怖症倾向")
	if buf == "WS-":
            print "WS-"
	    os.system("python /root/work/1.py 你此刻的心情:消极；灰暗；低迷；颓废,有抑郁症倾向")
    
    except:
        print "error"

connection.close()
